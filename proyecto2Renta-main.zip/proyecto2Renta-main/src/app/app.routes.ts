import { Routes } from '@angular/router';
import { ServiciosComponent } from './servicios/servicios.component';

export const routes: Routes = [
    {path: 'servicios', component:ServiciosComponent},
];
