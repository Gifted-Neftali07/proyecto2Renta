import { Routes } from '@angular/router';
import { ServiciosComponent } from './servicios/servicios.component';
import { AltaClienteComponent } from './clientes/alta-cliente/alta-cliente.component';
import { VehiculosComponent } from './vehiculos/vehiculos.component';
import { ListadoClientesComponent } from './clientes/listado-clientes/listado-clientes.component';
import { ListadoDesClientesComponent } from './clientes/listado-des-clientes/listado-des-clientes.component';

export const routes: Routes = [
    {path: 'servicios', component:ServiciosComponent},
    {path: 'alta-cliente', component: AltaClienteComponent},
    {path: 'vehiculos', component:VehiculosComponent},
    {path: 'listado-clientes', component:ListadoClientesComponent},
    {path: 'listado-des-clientes', component:ListadoDesClientesComponent},
];
